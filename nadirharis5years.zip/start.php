<?php
date_default_timezone_set('Africa/Cairo');
$config = json_decode(file_get_contents('config.json'),1);
$id = $config['id'];
$token = $config['token'];
$config['filter'] = $config['filter'] != null ? $config['filter'] : 1;
$screen = file_get_contents('screen');
exec('kill -9 ' . file_get_contents($screen . 'pid'));
file_put_contents($screen . 'pid', getmypid());
include 'index.php';
$accounts = json_decode(file_get_contents('accounts.json') , 1);
$cookies = $accounts[$screen]['cookies'] . $accounts[$screen]['sessionid'];
$useragent = $accounts[$screen]['useragent'];
$users = explode("\n", file_get_contents($screen));
$uu = explode(':', $screen) [0];
$se = 100;
$i = 0;
$gmail = 0;
$hotmail = 0;
$yahoo = 0;
$mailru = 0;
$true = 0;
$false = 0;
$NotBussines = 0;
function verfmatch($email){
    $check_mail = inInsta($email);
    if ($check_mail !== false) {
   if(strstr($email,"@gmail.com")){
     $ban = check_ban($email);
      if($ban == "Yes"){
         return "Good";
          }
      }else{
    return "Good";
      }
    }else{
    print_r($check_mail);
    }
  }
$edit = bot('sendMessage',[
    'chat_id'=>$id,
    'text'=>"*𝚂𝚃𝙰𝚁𝚃 𝙲𝙷𝙴𝙲𝙺 🧭
            𝙱𝚈: 𝙼𝙰𝚁𝙾*",
    'parse_mode'=>'markdown',
    'reply_markup'=>json_encode([
            'inline_keyboard'=>[
                [['text'=>'🎡 𝙲𝙷𝙴𝙲𝙴𝙳: '.$i,'callback_data'=>'fgf']],
                [['text'=>'📡 𝚄𝚂𝙴𝚁: '.$user,'callback_data'=>'fgdfg']],
                [['text'=>"𝙶𝙼𝙰𝙸𝙻: $gmail",'callback_data'=>'dfgfd'],['text'=>"𝚈𝙰𝙷𝙾𝙾: $yahoo",'callback_data'=>'gdfgfd']],
                [['text'=>'𝙼𝙰𝙸𝙻 𝚁𝚄: '.$mailru,'callback_data'=>'fgd'],['text'=>'𝙷𝙾𝚃𝙼𝙰𝙸𝙻: '.$hotmail,'callback_data'=>'ghj']],
                [['text'=>'𝚃𝚁𝚄𝙴 ✅: '.$true,'callback_data'=>'gj']],
                [['text'=>'𝙵𝙰𝙻𝚂𝙴 ❎: '.$false,'callback_data'=>'dghkf']],
                [['text'=>'𝙽𝙾𝚃 𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚥: '.$NotBussines,'callback_data'=>'dgdge']],
                [['text'=>'𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚦: '.$false,'callback_data'=>'dghkf']]
            ]
        ])
]);
$se = 100;
$editAfter = 1;
foreach ($users as $user) {
    $info = getInfo($user, $cookies, $useragent);
    if ($info != false ) {
        $mail = trim($info['mail']);
        $usern = $info['user'];
        $e = explode('@', $mail);
               if (preg_match('/(live|hotmail|outlook|yahoo|Yahoo|yAhoo|YAhoo|yaHoo)\.(.*)|(gmail)\.(com)|(mail|bk|yandex|inbox|list)\.(ru)/i', $mail,$m)) {
            echo 'check ' . $mail . PHP_EOL;
                    if(checkMail($mail)){
                        $inInsta = verfmatch($mail);
                        if ($inInsta == "Good") {
                            // if($config['filter'] <= $follow){
                                echo "True - $user - " . $mail . "\n";
                                if(strpos($mail, 'gmail.com')){
                                    $gmail += 1;
                                } elseif(strpos($mail, 'hotmail.') or strpos($mail,'outlook.') or strpos($mail,'live.com')){
                                    $hotmail += 1;
                                } elseif(strpos($mail, 'yahoo')){
                                    $yahoo += 1;
                                } elseif(preg_match('/(mail|bk|yandex|inbox|list)\.(ru)/i', $mail)){
                                    $mailru += 1;
                                }
                                $follow = $info['f'];
                                $following = $info['ff'];
                                $media = $info['m'];
                                bot('sendMessage', ['disable_web_page_preview' => true, 'chat_id' => $id, 'text' => "*𝒉𝒊 𝒔𝒊𝒓 𝒏𝒆𝒘 𝒇𝒖𝒄𝒌𝒆𝒅✅𖤧*  \n●>>>>>>>>>>>>>>>>>>●\n 
💵U𝒔𝒆𝒓 : [$usern](instagram.com/$usern) 
💵E𝒎𝒂𝒊𝒍 : [$mail] 
💵F𝒐𝒍𝒍𝒐𝒘𝒆𝒓𝒔 : $follow 
💵F𝒐𝒍𝒍𝒐𝒘𝒊𝒏𝒈 : $following 
💵P𝒐𝒔𝒕 : $media 
\n●>>>>>>>>>>>>>>>>>>●\n ↯𝚃𝙴𝙻𝙴↯
 :- [ @MA_Ro1 ]",
                                
                                'parse_mode'=>'markdown']);
                                
                                bot('editMessageReplyMarkup',[
                                    'chat_id'=>$id,
                                    'message_id'=>$edit->result->message_id,
                                    'reply_markup'=>json_encode([
                                        'inline_keyboard'=>[
                                            [['text'=>'🎡 𝙲𝙷𝙴𝙲𝙴𝙳: '.$i,'callback_data'=>'fgf']],
                                            [['text'=>'📡 𝚄𝚂𝙴𝚁: '.$user,'callback_data'=>'fgdfg']],
                                            [['text'=>"𝙶𝙼𝙰𝙸𝙻: $gmail",'callback_data'=>'dfgfd'],['text'=>"𝚈𝙰𝙷𝙾𝙾: $yahoo",'callback_data'=>'gdfgfd']],
                                            [['text'=>'𝙼𝙰𝙸𝙻 𝚁𝚄: '.$mailru,'callback_data'=>'fgd'],['text'=>'𝙷𝙾𝚃𝙼𝙰𝙸𝙻: '.$hotmail,'callback_data'=>'ghj']],
                                            [['text'=>'𝚃𝚁𝚄𝙴 ✅: '.$true,'callback_data'=>'gj']],
                                            [['text'=>'𝙵𝙰𝙻𝚂𝙴 ❎: '.$false,'callback_data'=>'dghkf']],
                                            [['text'=>'𝙽𝙾𝚃 𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚥: '.$NotBussines,'callback_data'=>'dgdge']],
                                            [['text'=>'𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚦: '.$false,'callback_data'=>'dghkf']]
                                        ]
                                    ])
                                ]);
                                $true += 1;
                            // } else {
                            //     echo "Filter , ".$mail.PHP_EOL;
                            // }
                            
                        } else {
                          echo "No Rest $mail\n";
                        }
                    } else {
                        $false +=1;
                        echo "Not Vaild 2 - $mail\n";
                    }
        } else {
          echo "BlackList - $mail\n";
        }
    } else {
         $NotBussines +=1;
        echo "NotBussines - $user\n";
    }
    usleep(510000);
    $i++;
    if($i == $editAfter){
        bot('editMessageReplyMarkup',[
            'chat_id'=>$id,
            'message_id'=>$edit->result->message_id,
            'reply_markup'=>json_encode([
                'inline_keyboard'=>[
                    [['text'=>'🎡 𝙲𝙷𝙴𝙲𝙴𝙳: '.$i,'callback_data'=>'fgf']],
                    [['text'=>'📡 𝚄𝚂𝙴𝚁: '.$user,'callback_data'=>'fgdfg']],
                    [['text'=>"𝙶𝙼𝙰𝙸𝙻: $gmail",'callback_data'=>'dfgfd'],['text'=>"𝚈𝙰𝙷𝙾𝙾: $yahoo",'callback_data'=>'gdfgfd']],
                    [['text'=>'𝙼𝙰𝙸𝙻 𝚁𝚄: '.$mailru,'callback_data'=>'fgd'],['text'=>'𝙷𝙾𝚃𝙼𝙰𝙸𝙻: '.$hotmail,'callback_data'=>'ghj']],
                    [['text'=>'𝚃𝚁𝚄𝙴 ✅: '.$true,'callback_data'=>'gj']],
                    [['text'=>'𝙵𝙰𝙻𝚂𝙴 ❎: '.$false,'callback_data'=>'dghkf']],
                    [['text'=>'𝙽𝙾𝚃 𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚥: '.$NotBussines,'callback_data'=>'dgdge']],
                    [['text'=>'𝙱𝚄𝚂𝙸𝙽𝙴𝚂𝚂 🚦: '.$false,'callback_data'=>'dghkf']]
                ]
            ])
        ]);
        $editAfter += 1;
    }
}
bot('sendMessage', ['chat_id' => $id, 'text' =>"Stop Checking : ".explode(':',$screen)[0]]);

